# ERP Autocenter

Sistema base em PHP + MySQL + PDO para gestão de autocenter.

## Ambiente
- XAMPP (Apache + MySQL)
- PHP 8+
- MySQL/MariaDB
- phpMyAdmin

## Instalação
1. Copie a pasta `erp_autocenter` para `C:\xampp\htdocs\`.
2. Inicie Apache e MySQL no XAMPP.
3. Acesse o phpMyAdmin e importe `database/banco.sql`.
4. Confira `php/db_connect.php` (usuário padrão XAMPP: root, senha vazia).
5. Abra `http://localhost/erp_autocenter/`.

## Recibo
O módulo `php/documentos/gerar_recibo.php` monta um recibo de venda/serviço em HTML para impressão ou salvamento como PDF pelo navegador. O layout segue a lógica do modelo fornecido: cabeçalho da empresa, venda, cliente, itens de produtos/serviços, totais, financeiro e observações.

## Acesso inicial
Usuário: admin
Senha: admin123

Altere a senha em produção.

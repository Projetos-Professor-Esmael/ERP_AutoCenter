# Versão inicial
- Estrutura base ERP Autocenter.
- Banco MySQL com usuários, funcionários, clientes, produtos, serviços, vendas, itens, financeiro, estoque e relatórios.
- Venda demonstrativa #11060.
- Recibo integrado em HTML para impressão/Salvar como PDF.
- Dashboard inicial responsivo.

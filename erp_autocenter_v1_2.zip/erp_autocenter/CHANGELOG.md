# CHANGELOG — ERP Autocenter

## Versão 1.2 — Controle de acesso e recibo configurável

- Acesso obrigatório por `login.php`.
- Redirecionamento de sessão e logout revisados.
- Criado `cadastro.php` com criação de conta.
- Criado `recuperar.php` com token de redefinição.
- Usuários receberam e-mail para recuperação.
- Perfis ampliados: ADMIN, GERENTE, VENDEDOR, TECNICO e ATENDENTE.
- Funcionários passaram a usar seletor de cargo.
- Criadas tabelas `perfil_permissoes` e `usuario_permissoes`.
- Criada matriz de permissões Visualizar/Criar/Editar/Excluir.
- Gestão de usuários com aplicação de perfil e permissões individuais.
- Menus passam a respeitar permissões.
- API passa a validar permissões no servidor, não somente na interface.
- Criada tabela `configuracoes` para partes fixas do recibo.
- Recibo passou a carregar dados fixos do banco.
- Configuração de empresa/recibo adicionada ao sistema.
- Recibo também exige sessão válida.
- Bootstrap 5 e Bootstrap Icons mantidos como padrão visual.

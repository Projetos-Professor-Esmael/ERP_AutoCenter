<?php
declare(strict_types=1);
session_start();
require_once __DIR__.'/php/db_connect.php';
$erro=''; $msg=''; $resetUrl=''; $token=$_GET['token']??'';
if($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['solicitar'])){
    $login=trim($_POST['login']??''); $email=trim($_POST['email']??'');
    $st=$pdo->prepare('SELECT id FROM usuarios WHERE login=? AND email=? AND ativo=1 LIMIT 1'); $st->execute([$login,$email]); $u=$st->fetch();
    if(!$u){$erro='Não foi possível localizar uma conta ativa com esses dados.';} else {
        $token=bin2hex(random_bytes(24)); $exp=(new DateTime('+30 minutes'))->format('Y-m-d H:i:s');
        $pdo->prepare('DELETE FROM recuperacao_senha WHERE usuario_id=?')->execute([$u['id']]);
        $pdo->prepare('INSERT INTO recuperacao_senha(usuario_id,token,expira_em) VALUES(?,?,?)')->execute([$u['id'],$token,$exp]);
        $resetUrl='recuperar.php?token='.$token; $msg='Solicitação criada. Em ambiente local, o link de redefinição é exibido abaixo. Em produção, ele deve ser enviado por e-mail.';
    }
}
if($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['redefinir'])){
    $token=trim($_POST['token']??''); $senha=$_POST['senha']??''; $conf=$_POST['confirmar_senha']??'';
    $st=$pdo->prepare('SELECT * FROM recuperacao_senha WHERE token=? AND usado=0 AND expira_em>=NOW() LIMIT 1'); $st->execute([$token]); $r=$st->fetch();
    if(!$r)$erro='Link de redefinição inválido ou expirado.'; elseif(strlen($senha)<6)$erro='A nova senha deve ter pelo menos 6 caracteres.'; elseif($senha!==$conf)$erro='As senhas não conferem.'; else {$pdo->prepare('UPDATE usuarios SET senha=? WHERE id=?')->execute([password_hash($senha,PASSWORD_DEFAULT),$r['usuario_id']]);$pdo->prepare('UPDATE recuperacao_senha SET usado=1 WHERE id=?')->execute([$r['id']]);$msg='Senha redefinida com sucesso. Volte ao login.';$token='';}
}
?><!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Recuperar senha | ERP Autocenter</title><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"><link href="css/style.css" rel="stylesheet"></head><body class="login-page"><div class="container py-5"><div class="row justify-content-center"><div class="col-md-7 col-lg-5"><div class="card shadow-lg border-0"><div class="card-body p-4 p-lg-5"><h1 class="h4 fw-bold">Recuperar senha</h1><p class="text-secondary">Informe login e e-mail cadastrados.</p><?php if($erro):?><div class="alert alert-danger"><?=htmlspecialchars($erro)?></div><?php endif;?><?php if($msg):?><div class="alert alert-success"><?=htmlspecialchars($msg)?></div><?php endif;?><?php if($resetUrl):?><div class="alert alert-warning small"><b>Link local de redefinição:</b><br><a href="<?=htmlspecialchars($resetUrl)?>"><?=htmlspecialchars($resetUrl)?></a></div><?php endif;?><?php if($token):?><form method="post"><input type="hidden" name="token" value="<?=htmlspecialchars($token)?>"><div class="mb-3"><label class="form-label">Nova senha</label><input type="password" name="senha" class="form-control" required minlength="6"></div><div class="mb-3"><label class="form-label">Confirmar nova senha</label><input type="password" name="confirmar_senha" class="form-control" required minlength="6"></div><button name="redefinir" class="btn btn-primary w-100">Redefinir senha</button></form><?php else:?><form method="post"><div class="mb-3"><label class="form-label">Login</label><input name="login" class="form-control" required></div><div class="mb-3"><label class="form-label">E-mail</label><input type="email" name="email" class="form-control" required></div><button name="solicitar" class="btn btn-primary w-100">Gerar recuperação</button></form><?php endif;?><div class="text-center mt-3"><a href="login.php">Voltar para o login</a></div></div></div></div></div></div></body></html>

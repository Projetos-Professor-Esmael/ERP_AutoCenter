# ERP Autocenter — versão integrada

Aplicação web em **PHP + MySQL + PDO + Bootstrap 5**, preparada para execução no XAMPP.

## Acesso

O sistema é protegido por sessão e o ponto de entrada é:

`http://localhost/erp_autocenter/login.php`

Não é necessário abrir `index.php` diretamente: sem sessão válida o acesso é bloqueado e redirecionado ao login.

### Usuário inicial

- Login: `admin`
- Senha: `admin123`

Troque a senha depois da instalação.

## Recursos implementados

- Login, logout e controle de sessão.
- Criar conta diretamente na tela de login.
- Recuperação de senha com token de uso único e validade de 30 minutos. Em ambiente local o link é exibido na tela; em produção deve ser integrado a um serviço de e-mail.
- Dashboard protegido.
- CRUD de clientes.
- CRUD de produtos/estoque.
- CRUD de serviços.
- CRUD de funcionários.
- Seletor de cargo do funcionário: Gerente, Vendedor, Técnico e Administrador.
- Vendas com produtos e serviços na mesma operação.
- Baixa automática de estoque.
- Cancelamento de venda com devolução ao estoque.
- Financeiro integrado às vendas e lançamentos avulsos.
- Gestão de usuários exclusivamente para ADMIN.
- Perfis: ADMIN, GERENTE, VENDEDOR, TECNICO e ATENDENTE.
- Matriz individual de permissões por módulo: Visualizar, Criar, Editar e Excluir.
- Perfil aplica permissões padrão; o administrador pode restringir/liberar cada módulo por usuário.
- Ativação/inativação de usuários e cadastros.
- Configuração das partes fixas do recibo: empresa, telefone, atividade, PIX/CNPJ, responsável, título, rodapé e observação padrão.
- Recibo protegido por login e carregado com dados reais do banco.

## Instalação

1. Copie a pasta `erp_autocenter` para `C:\xampp\htdocs\`.
2. Inicie Apache e MySQL no XAMPP.
3. Abra o phpMyAdmin.
4. Importe `database/banco.sql`.
5. Acesse `http://localhost/erp_autocenter/login.php`.
6. Entre com `admin / admin123`.

## Estrutura principal

```text
erp_autocenter/
├── login.php
├── cadastro.php
├── recuperar.php
├── index.php
├── api/
│   └── api.php
├── css/
│   └── style.css
├── js/
│   └── app.js
├── php/
│   ├── auth.php
│   ├── db_connect.php
│   ├── logout.php
│   └── documentos/
│       └── gerar_recibo.php
├── database/
│   └── banco.sql
└── assets/
```

## Recibo

O recibo continua seguindo a estrutura do modelo fornecido: dados fixos da empresa, número da venda, cliente, produtos/serviços, totais, financeiro, observações gerais e observações técnicas.

As partes fixas agora vêm da tabela `configuracoes` e podem ser alteradas no menu **Recibo / Empresa**.

O documento é um **recibo comercial**, não uma NF-e/NFC-e/NFS-e fiscal autorizada.

CREATE DATABASE IF NOT EXISTS erp_autocenter CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE erp_autocenter;

DROP TABLE IF EXISTS movimentacoes_estoque;
DROP TABLE IF EXISTS financeiro;
DROP TABLE IF EXISTS vendas_itens;
DROP TABLE IF EXISTS vendas;
DROP TABLE IF EXISTS servicos;
DROP TABLE IF EXISTS produtos;
DROP TABLE IF EXISTS clientes;
DROP TABLE IF EXISTS funcionarios;
DROP TABLE IF EXISTS recuperacao_senha;
DROP TABLE IF EXISTS usuario_permissoes;
DROP TABLE IF EXISTS perfil_permissoes;
DROP TABLE IF EXISTS configuracoes;
DROP TABLE IF EXISTS usuarios;

CREATE TABLE usuarios (
 id INT AUTO_INCREMENT PRIMARY KEY,
 nome VARCHAR(120) NOT NULL,
 email VARCHAR(150),
 login VARCHAR(60) NOT NULL UNIQUE,
 senha VARCHAR(255) NOT NULL,
 perfil ENUM('ADMIN','GERENTE','VENDEDOR','TECNICO','ATENDENTE') NOT NULL DEFAULT 'ATENDENTE',
 ativo TINYINT(1) NOT NULL DEFAULT 1,
 criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;


CREATE TABLE perfil_permissoes (
 id INT AUTO_INCREMENT PRIMARY KEY,
 perfil ENUM('ADMIN','GERENTE','VENDEDOR','TECNICO','ATENDENTE') NOT NULL,
 modulo VARCHAR(40) NOT NULL,
 visualizar TINYINT(1) NOT NULL DEFAULT 0,
 criar TINYINT(1) NOT NULL DEFAULT 0,
 editar TINYINT(1) NOT NULL DEFAULT 0,
 excluir TINYINT(1) NOT NULL DEFAULT 0,
 UNIQUE KEY uq_perfil_modulo(perfil,modulo)
) ENGINE=InnoDB;

CREATE TABLE usuario_permissoes (
 id INT AUTO_INCREMENT PRIMARY KEY,
 usuario_id INT NOT NULL,
 modulo VARCHAR(40) NOT NULL,
 visualizar TINYINT(1) NOT NULL DEFAULT 0,
 criar TINYINT(1) NOT NULL DEFAULT 0,
 editar TINYINT(1) NOT NULL DEFAULT 0,
 excluir TINYINT(1) NOT NULL DEFAULT 0,
 UNIQUE KEY uq_usuario_modulo(usuario_id,modulo),
 FOREIGN KEY(usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE configuracoes (
 chave VARCHAR(80) PRIMARY KEY,
 valor TEXT NULL,
 atualizado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE recuperacao_senha (
 id INT AUTO_INCREMENT PRIMARY KEY,
 usuario_id INT NOT NULL,
 token VARCHAR(100) NOT NULL UNIQUE,
 expira_em DATETIME NOT NULL,
 usado TINYINT(1) NOT NULL DEFAULT 0,
 FOREIGN KEY(usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE funcionarios (
 id INT AUTO_INCREMENT PRIMARY KEY,
 nome VARCHAR(120) NOT NULL,
 cpf VARCHAR(20), cargo ENUM('GERENTE','VENDEDOR','TECNICO','ADMINISTRADOR') NOT NULL DEFAULT 'VENDEDOR', telefone VARCHAR(30), ativo TINYINT(1) DEFAULT 1,
 criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE clientes (
 id INT AUTO_INCREMENT PRIMARY KEY,
 nome VARCHAR(150) NOT NULL,
 documento VARCHAR(30), telefone VARCHAR(30), email VARCHAR(150), endereco VARCHAR(255), cidade VARCHAR(100), estado VARCHAR(2),
 ativo TINYINT(1) NOT NULL DEFAULT 1,
 criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE produtos (
 id INT AUTO_INCREMENT PRIMARY KEY,
 codigo VARCHAR(50) UNIQUE,
 nome VARCHAR(160) NOT NULL,
 categoria VARCHAR(100),
 estoque DECIMAL(12,2) NOT NULL DEFAULT 0,
 estoque_minimo DECIMAL(12,2) NOT NULL DEFAULT 0,
 preco DECIMAL(12,2) NOT NULL DEFAULT 0,
 ativo TINYINT(1) DEFAULT 1,
 criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE servicos (
 id INT AUTO_INCREMENT PRIMARY KEY,
 nome VARCHAR(160) NOT NULL,
 descricao TEXT,
 preco DECIMAL(12,2) NOT NULL DEFAULT 0,
 ativo TINYINT(1) DEFAULT 1,
 criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE vendas (
 id INT AUTO_INCREMENT PRIMARY KEY,
 numero INT NOT NULL UNIQUE,
 cliente_id INT NULL,
 usuario_id INT NULL,
 data_venda DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 desconto DECIMAL(12,2) NOT NULL DEFAULT 0,
 observacoes TEXT,
 observacoes_tecnicas TEXT,
 status ENUM('ABERTA','FINALIZADA','CANCELADA') DEFAULT 'FINALIZADA',
 FOREIGN KEY (cliente_id) REFERENCES clientes(id) ON DELETE SET NULL,
 FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE vendas_itens (
 id INT AUTO_INCREMENT PRIMARY KEY,
 venda_id INT NOT NULL,
 tipo ENUM('PRODUTO','SERVICO') NOT NULL,
 produto_id INT NULL,
 servico_id INT NULL,
 descricao VARCHAR(255) NOT NULL,
 preco_unitario DECIMAL(12,2) NOT NULL,
 quantidade DECIMAL(12,2) NOT NULL DEFAULT 1,
 desconto DECIMAL(12,2) NOT NULL DEFAULT 0,
 total DECIMAL(12,2) NOT NULL,
 FOREIGN KEY (venda_id) REFERENCES vendas(id) ON DELETE CASCADE,
 FOREIGN KEY (produto_id) REFERENCES produtos(id) ON DELETE SET NULL,
 FOREIGN KEY (servico_id) REFERENCES servicos(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE financeiro (
 id INT AUTO_INCREMENT PRIMARY KEY,
 venda_id INT NULL,
 descricao VARCHAR(255) NOT NULL,
 tipo ENUM('RECEITA','DESPESA') NOT NULL DEFAULT 'RECEITA',
 valor DECIMAL(12,2) NOT NULL,
 vencimento DATE,
 pagamento DATE,
 forma_pagamento VARCHAR(60),
 status ENUM('PENDENTE','PAGO','CANCELADO') DEFAULT 'PENDENTE',
 FOREIGN KEY (venda_id) REFERENCES vendas(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE movimentacoes_estoque (
 id INT AUTO_INCREMENT PRIMARY KEY,
 produto_id INT NOT NULL,
 tipo ENUM('ENTRADA','SAIDA','AJUSTE') NOT NULL,
 quantidade DECIMAL(12,2) NOT NULL,
 origem VARCHAR(100), referencia_id INT,
 criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY (produto_id) REFERENCES produtos(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE INDEX idx_fin_status ON financeiro(status);
CREATE INDEX idx_vendas_data ON vendas(data_venda);
CREATE INDEX idx_mov_produto ON movimentacoes_estoque(produto_id);

INSERT INTO usuarios(nome,login,senha,perfil,ativo) VALUES ('Administrador','admin','$2y$12$L0Wtl.QLxWYOCkI97Dn3uObwjH9t6NR2KFkpECOm1.ATY/bUlNLRu','ADMIN',1);

INSERT INTO perfil_permissoes(perfil,modulo,visualizar,criar,editar,excluir) VALUES
('ADMIN','dashboard',1,0,0,0),('ADMIN','clientes',1,1,1,1),('ADMIN','produtos',1,1,1,1),('ADMIN','servicos',1,1,1,1),('ADMIN','vendas',1,1,1,1),('ADMIN','financeiro',1,1,1,1),('ADMIN','funcionarios',1,1,1,1),('ADMIN','usuarios',1,1,1,1),('ADMIN','configuracoes',1,1,1,1),
('GERENTE','dashboard',1,0,0,0),('GERENTE','clientes',1,1,1,0),('GERENTE','produtos',1,1,1,0),('GERENTE','servicos',1,1,1,0),('GERENTE','vendas',1,1,1,0),('GERENTE','financeiro',1,1,1,0),('GERENTE','funcionarios',1,0,1,0),
('VENDEDOR','dashboard',1,0,0,0),('VENDEDOR','clientes',1,1,1,0),('VENDEDOR','produtos',1,0,0,0),('VENDEDOR','servicos',1,0,0,0),('VENDEDOR','vendas',1,1,1,0),
('TECNICO','dashboard',1,0,0,0),('TECNICO','clientes',1,0,0,0),('TECNICO','produtos',1,0,0,0),('TECNICO','servicos',1,0,0,0),('TECNICO','vendas',1,1,1,0),
('ATENDENTE','dashboard',1,0,0,0),('ATENDENTE','clientes',1,1,1,0),('ATENDENTE','produtos',1,0,0,0),('ATENDENTE','servicos',1,0,0,0),('ATENDENTE','vendas',1,1,1,0);

INSERT INTO usuario_permissoes(usuario_id,modulo,visualizar,criar,editar,excluir)
SELECT 1,modulo,visualizar,criar,editar,excluir FROM perfil_permissoes WHERE perfil='ADMIN';

INSERT INTO configuracoes(chave,valor) VALUES
('empresa_nome','AUTOCAR SUSPENSÕES'),
('empresa_telefone','27 99970-2359'),
('empresa_atividade','PRODUTOS REMANUFATURADOS'),
('empresa_pix','CHAVE PIX CNPJ: 37121898000166'),
('empresa_responsavel','ROGERIA FOLLADOR'),
('recibo_titulo','RECIBO DE VENDA OU SERVIÇO'),
('recibo_rodape','Obrigado pela preferência!'),
('recibo_observacao_padrao','');

-- senha do usuário acima: admin123
INSERT INTO clientes(nome,documento,telefone,email,endereco,cidade,estado) VALUES ('Cliente Exemplo','000.000.000-00','(27) 99999-9999','cliente@exemplo.com','Rua Exemplo, 100','Vila Velha','ES');
INSERT INTO produtos(codigo,nome,categoria,estoque,estoque_minimo,preco) VALUES
('P001','Pivo Polo Fox Perfect','Suspensão',10,2,80.00),('P002','Bucha Balança Maior Fox','Suspensão',15,3,80.00),('P003','Bucha Balança Menor','Suspensão',15,3,50.00);
INSERT INTO servicos(nome,descricao,preco) VALUES ('Alinhamento','Alinhamento de direção',70.00),('Mão de obra instalação','Instalação e montagem',280.00);
INSERT INTO vendas(numero,cliente_id,usuario_id,desconto,observacoes,observacoes_tecnicas,status) VALUES (11060,1,1,0,'TROCADO PIVO LADO DIREITO','PRECISA TROCAR 2 APOIO DE COLUNA DIANT; 1 CAIXA DE DIREÇÃO HIDRAULICA COM FOLGA','FINALIZADA');
SET @venda=LAST_INSERT_ID();
INSERT INTO vendas_itens(venda_id,tipo,produto_id,descricao,preco_unitario,quantidade,desconto,total) VALUES
(@venda,'PRODUTO',1,'Pivo Polo Fox Perfect',80,1,0,80),(@venda,'PRODUTO',2,'Bucha Balança Maior Fox',80,1,0,80),(@venda,'PRODUTO',3,'Bucha Balança Menor',50,1,0,50),(@venda,'PRODUTO',1,'Pivo Polo Fox Perfect',80,3,0,240),(@venda,'SERVICO',1,'Alinhamento',70,1,0,70),(@venda,'SERVICO',2,'Mão de obra instalação',280,1,0,280);
UPDATE produtos SET estoque=estoque-4 WHERE id=1;
INSERT INTO movimentacoes_estoque(produto_id,tipo,quantidade,origem,referencia_id) VALUES (1,'SAIDA','4','VENDA',@venda),(2,'SAIDA','1','VENDA',@venda),(3,'SAIDA','1','VENDA',@venda);
INSERT INTO financeiro(venda_id,descricao,tipo,valor,vencimento,pagamento,forma_pagamento,status) VALUES
(@venda,'Parcela 1/2','RECEITA',700,CURDATE(),CURDATE(),'Dinheiro','PAGO'),(@venda,'Parcela 2/2','RECEITA',100,DATE_ADD(CURDATE(),INTERVAL 30 DAY),CURDATE(),'Pix Rogeria','PAGO');

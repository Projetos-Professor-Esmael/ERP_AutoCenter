<?php
declare(strict_types=1);
session_start();
require_once __DIR__.'/php/db_connect.php';
if (!empty($_SESSION['usuario_id'])) { header('Location: index.php'); exit; }
$erro=''; $ok='';
if($_SERVER['REQUEST_METHOD']==='POST'){
    $nome=trim($_POST['nome']??''); $login=trim($_POST['login']??''); $email=trim($_POST['email']??''); $senha=$_POST['senha']??''; $conf=$_POST['confirmar_senha']??'';
    try{
        if(mb_strlen($nome)<3) throw new Exception('Informe seu nome completo.');
        if(mb_strlen($login)<3) throw new Exception('O login deve ter pelo menos 3 caracteres.');
        if(mb_strlen($senha)<6) throw new Exception('A senha deve ter pelo menos 6 caracteres.');
        if($senha!==$conf) throw new Exception('As senhas não conferem.');
        $st=$pdo->prepare('SELECT id FROM usuarios WHERE login=? LIMIT 1'); $st->execute([$login]); if($st->fetch()) throw new Exception('Este login já está cadastrado.');
        $st=$pdo->prepare('INSERT INTO usuarios(nome,login,email,senha,perfil,ativo) VALUES(?,?,?,? ,\'ATENDENTE\',1)');
        $st->execute([$nome,$login,$email?:null,password_hash($senha,PASSWORD_DEFAULT)]);
        $uid=(int)$pdo->lastInsertId();
        $pdo->prepare('INSERT INTO usuario_permissoes(usuario_id,modulo,visualizar,criar,editar,excluir) SELECT ?,modulo,visualizar,criar,editar,excluir FROM perfil_permissoes WHERE perfil=\'ATENDENTE\'')->execute([$uid]);
        $ok='Conta criada com sucesso. Você já pode entrar no sistema.';
    }catch(Throwable $e){$erro=$e->getMessage();}
}
?><!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Criar conta | ERP Autocenter</title><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"><link href="css/style.css" rel="stylesheet"></head><body class="login-page"><div class="container py-5"><div class="row justify-content-center"><div class="col-md-7 col-lg-5"><div class="card shadow-lg border-0"><div class="card-body p-4 p-lg-5"><h1 class="h4 fw-bold">Criar conta</h1><p class="text-secondary">Novo usuário entra inicialmente como <b>Atendente</b>. O administrador pode alterar perfil e permissões depois.</p><?php if($erro):?><div class="alert alert-danger"><?=htmlspecialchars($erro)?></div><?php endif;?><?php if($ok):?><div class="alert alert-success"><?=htmlspecialchars($ok)?></div><?php endif;?><form method="post"><div class="mb-3"><label class="form-label">Nome completo</label><input name="nome" class="form-control" required value="<?=htmlspecialchars($_POST['nome']??'')?>"></div><div class="row"><div class="col-md-6 mb-3"><label class="form-label">Login</label><input name="login" class="form-control" required value="<?=htmlspecialchars($_POST['login']??'')?>"></div><div class="col-md-6 mb-3"><label class="form-label">E-mail</label><input type="email" name="email" class="form-control" value="<?=htmlspecialchars($_POST['email']??'')?>"></div></div><div class="row"><div class="col-md-6 mb-3"><label class="form-label">Senha</label><input type="password" name="senha" class="form-control" required minlength="6"></div><div class="col-md-6 mb-3"><label class="form-label">Confirmar senha</label><input type="password" name="confirmar_senha" class="form-control" required minlength="6"></div></div><button class="btn btn-primary w-100">Criar conta</button></form><div class="text-center mt-3"><a href="login.php">Voltar para o login</a></div></div></div></div></div></div></body></html>

<?php
declare(strict_types=1);
if (session_status() === PHP_SESSION_NONE) session_start();
function exigir_login(): void {
    if (empty($_SESSION['usuario_id'])) { header('Location: login.php'); exit; }
}
function usuario_atual(): array { return ['id'=>(int)($_SESSION['usuario_id']??0),'nome'=>$_SESSION['usuario_nome']??'','perfil'=>$_SESSION['usuario_perfil']??'']; }
function exigir_admin(): void { if (($_SESSION['usuario_perfil']??'')!=='ADMIN') { http_response_code(403); exit('Acesso restrito ao administrador.'); } }
function tem_permissao(PDO $pdo, string $modulo, string $acao='visualizar'): bool {
    if (($_SESSION['usuario_perfil']??'')==='ADMIN') return true;
    $permitidas=['visualizar','criar','editar','excluir']; if(!in_array($acao,$permitidas,true)) return false;
    $st=$pdo->prepare("SELECT $acao FROM usuario_permissoes WHERE usuario_id=? AND modulo=? LIMIT 1"); $st->execute([(int)($_SESSION['usuario_id']??0),$modulo]); return (bool)$st->fetchColumn();
}
function exigir_permissao(PDO $pdo,string $modulo,string $acao='visualizar'): void { if(!tem_permissao($pdo,$modulo,$acao)){http_response_code(403);exit('Você não possui permissão para esta operação.');} }

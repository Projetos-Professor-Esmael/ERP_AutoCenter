# ERP Autocenter — atualização integrada

## 1.1.0
- Migração da tela estática para aplicação PHP protegida por sessão.
- Implementação de Bootstrap 5 e Bootstrap Icons.
- Dashboard conectado ao MySQL.
- CRUD de clientes, produtos, serviços, funcionários e usuários.
- Controle de ativo/inativo nos cadastros aplicáveis.
- Venda integrada a produtos, serviços, estoque e financeiro.
- Transação SQL para finalizar venda com segurança.
- Cancelamento de venda com reversão de estoque.
- Financeiro com contas pendentes, pagas e canceladas.
- Login corrigido para usar `password_verify`.
- Recibo atualizado para consultar dados reais da operação.
- Banco inicial reorganizado para instalação limpa.

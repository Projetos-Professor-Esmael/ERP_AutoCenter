<?php
declare(strict_types=1); session_start(); require_once 'db_connect.php';
if(!empty($_SESSION['usuario_id'])){ header('Location: ../index.php'); exit; }
$erro='';
if($_SERVER['REQUEST_METHOD']==='POST'){
  $login=trim($_POST['login']??''); $senha=$_POST['senha']??'';
  $s=$pdo->prepare('SELECT * FROM usuarios WHERE login=? AND ativo=1 LIMIT 1'); $s->execute([$login]); $u=$s->fetch();
  if($u && password_verify($senha,$u['senha'])){ $_SESSION['usuario_id']=$u['id']; $_SESSION['usuario_nome']=$u['nome']; $_SESSION['usuario_perfil']=$u['perfil']; header('Location: ../index.php'); exit; }
  $erro='Login ou senha inválidos.';
}
?><!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Login | ERP Autocenter</title><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"><style>body{min-height:100vh;background:linear-gradient(135deg,#062b52,#0d6efd);}.card{border:0;border-radius:1rem}.brand{font-weight:800;letter-spacing:.08em}</style></head><body class="d-flex align-items-center"><div class="container"><div class="row justify-content-center"><div class="col-md-5 col-lg-4"><div class="card shadow-lg"><div class="card-body p-4"><div class="text-center mb-4"><div class="brand text-primary fs-3">ERP AUTOCENTER</div><small class="text-secondary">Gestão integrada</small></div><?php if($erro):?><div class="alert alert-danger py-2"><?=htmlspecialchars($erro)?></div><?php endif;?><form method="post"><div class="mb-3"><label class="form-label">Login</label><input name="login" class="form-control" required autofocus></div><div class="mb-3"><label class="form-label">Senha</label><input type="password" name="senha" class="form-control" required></div><button class="btn btn-primary w-100">Entrar</button></form><div class="text-center mt-3 small text-secondary">Acesso inicial: <b>admin</b> / <b>admin123</b></div></div></div></div></div></div></body></html>

<?php
declare(strict_types=1);
if(session_status()===PHP_SESSION_NONE) session_start();
function exigir_login(): void { if(empty($_SESSION['usuario_id'])) { header('Location: login.php'); exit; } }
function usuario_atual(): array { return ['id'=>(int)($_SESSION['usuario_id']??0),'nome'=>$_SESSION['usuario_nome']??'','perfil'=>$_SESSION['usuario_perfil']??'']; }
function exigir_admin(): void { if(($_SESSION['usuario_perfil']??'')!=='ADMIN'){ http_response_code(403); die('Acesso restrito ao administrador.'); } }

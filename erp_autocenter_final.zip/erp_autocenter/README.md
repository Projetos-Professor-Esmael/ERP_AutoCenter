# ERP Autocenter — versão integrada

Aplicação web para gestão de autocenter, desenvolvida para **XAMPP + Apache + PHP 8+ + MySQL/MariaDB + PDO**, com interface em **Bootstrap 5**.

## O que foi implementado

- Login com sessão e senha `password_hash/password_verify`.
- Dashboard com indicadores reais do banco.
- CRUD completo de clientes.
- CRUD completo de produtos/estoque.
- CRUD completo de serviços.
- CRUD completo de funcionários.
- CRUD completo de usuários (ADMIN).
- Cadastro de vendas com produtos e serviços na mesma operação.
- Baixa automática de estoque ao finalizar venda.
- Registro de movimentação de estoque.
- Geração automática de conta a receber.
- Módulo financeiro com cadastro e baixa de contas.
- Cancelamento de venda com reversão do estoque e cancelamento financeiro.
- Recibo de venda/serviço em HTML pronto para impressão/Salvar como PDF.
- Layout do recibo baseado no modelo fornecido pelo usuário.
- Bootstrap 5 + Bootstrap Icons.
- Interface responsiva para desktop e celular.

## Instalação

1. Copie `erp_autocenter` para `C:\xampp\htdocs\`.
2. Inicie **Apache** e **MySQL** no XAMPP.
3. Abra o phpMyAdmin.
4. Importe `database/banco.sql`.
5. Acesse `http://localhost/erp_autocenter/`.
6. Login inicial: `admin` / `admin123`.

> O banco de demonstração já cria a venda #11060, produtos, serviços, cliente, movimentações de estoque e lançamentos financeiros.

## Estrutura principal

```text
erp_autocenter/
├── index.php
├── api/api.php
├── css/style.css
├── js/app.js
├── php/
│   ├── auth.php
│   ├── db_connect.php
│   ├── login.php
│   ├── logout.php
│   └── documentos/gerar_recibo.php
└── database/banco.sql
```

## Integração da venda

Ao finalizar uma venda:

1. A venda é gravada.
2. Os itens são gravados.
3. Produtos têm o estoque reduzido dentro de uma transação.
4. A movimentação de saída é registrada.
5. Serviços não alteram estoque.
6. Uma conta a receber é criada no financeiro.
7. O recibo consulta os dados reais da venda, cliente, itens e financeiro.

Ao cancelar uma venda finalizada, o sistema devolve os produtos ao estoque, registra a entrada de reversão e cancela o lançamento financeiro.

## Recibo

Use **Vendas → Recibo**. O navegador abrirá o documento; use **Imprimir → Salvar como PDF**.

## Observação

Esta versão prioriza uma base funcional integrada. Recursos fiscais oficiais (NF-e/NFC-e/NFS-e, certificado digital, SEFAZ e emissão de documento fiscal autorizado) não estão implementados; o documento atual é um **recibo comercial**, conforme o modelo fornecido.

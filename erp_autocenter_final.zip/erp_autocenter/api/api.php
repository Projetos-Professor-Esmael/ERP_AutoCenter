<?php
declare(strict_types=1);
require_once __DIR__.'/../php/auth.php';
require_once __DIR__.'/../php/db_connect.php';
header('Content-Type: application/json; charset=utf-8');
if(empty($_SESSION['usuario_id'])){ http_response_code(401); echo json_encode(['ok'=>false,'message'=>'Sessão expirada.']); exit; }
function input(): array { $raw=file_get_contents('php://input'); return $raw? (json_decode($raw,true)?:[]):$_POST; }
function out(array $x): never { echo json_encode($x,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES); exit; }
function clean(array $d): array { foreach($d as $k=>$v) if(is_string($v)) $d[$k]=trim($v); return $d; }
$action=$_GET['action']??''; $in=input();
$module=$in['module']??''; $id=(int)($in['id']??0); $data=clean($in['data']??[]);
$allowed=['clientes'=>['nome','documento','telefone','email','endereco','cidade','estado'],'produtos'=>['codigo','nome','categoria','estoque','estoque_minimo','preco','ativo'],'servicos'=>['nome','descricao','preco','ativo'],'funcionarios'=>['nome','cpf','cargo','telefone','ativo'],'usuarios'=>['nome','login','senha','perfil','ativo']];
try{
 switch($action){
  case 'dashboard':
   $fat=(float)$pdo->query("SELECT COALESCE(SUM(f.valor),0) FROM financeiro f WHERE f.tipo='RECEITA' AND f.status='PAGO'")->fetchColumn();
   $pend=(float)$pdo->query("SELECT COALESCE(SUM(f.valor),0) FROM financeiro f WHERE f.status='PENDENTE'")->fetchColumn();
   out(['ok'=>true,'faturamento'=>$fat,'pendente'=>$pend,'vendas'=>(int)$pdo->query('SELECT COUNT(*) FROM vendas')->fetchColumn(),'produtos'=>(int)$pdo->query('SELECT COUNT(*) FROM produtos WHERE ativo=1')->fetchColumn()]);
  case 'list':
   if(!isset($allowed[$module])) throw new Exception('Módulo inválido.');
   $rows=$pdo->query('SELECT * FROM '.$module.' ORDER BY id DESC')->fetchAll(); out(['ok'=>true,'rows'=>$rows]);
  case 'save':
   if(!isset($allowed[$module])) throw new Exception('Módulo inválido.');
   if($module==='usuarios' && ($_SESSION['usuario_perfil']??'')!=='ADMIN') throw new Exception('Apenas ADMIN pode gerenciar usuários.');
   $cols=$allowed[$module]; $d=[]; foreach($cols as $c) if(array_key_exists($c,$data)) $d[$c]=$data[$c];
   if($module==='usuarios'){if(!$id && empty($d['senha'])) throw new Exception('Informe a senha.'); if(!empty($d['senha'])) $d['senha']=password_hash($d['senha'],PASSWORD_DEFAULT); else unset($d['senha']); $d['ativo']=(int)($d['ativo']??1);}
   if($module==='produtos'){foreach(['estoque','estoque_minimo','preco'] as $n)$d[$n]=(float)($d[$n]??0);}
   if(in_array($module,['servicos'],true))$d['preco']=(float)($d['preco']??0);
   if($id){$set=implode(',',array_map(fn($c)=>"$c=?",array_keys($d)));$vals=array_values($d);$vals[]=$id;$st=$pdo->prepare("UPDATE $module SET $set WHERE id=?");$st->execute($vals);}else{$keys=array_keys($d);$st=$pdo->prepare("INSERT INTO $module (".implode(',',$keys).") VALUES (".implode(',',array_fill(0,count($keys),'?')).")");$st->execute(array_values($d));$id=(int)$pdo->lastInsertId();}
   out(['ok'=>true,'id'=>$id]);
  case 'delete':
   if(!isset($allowed[$module])) throw new Exception('Módulo inválido.'); if($module==='usuarios' && ($_SESSION['usuario_perfil']??'')!=='ADMIN') throw new Exception('Apenas ADMIN pode gerenciar usuários.'); if($module==='usuarios' && $id===$_SESSION['usuario_id']) throw new Exception('Não exclua o usuário logado.');
   $st=$pdo->prepare("DELETE FROM $module WHERE id=?");$st->execute([$id]);out(['ok'=>true]);
  case 'options_products': out(['ok'=>true,'rows'=>$pdo->query("SELECT id,nome,preco,estoque FROM produtos WHERE ativo=1 ORDER BY nome")->fetchAll()]);
  case 'options_services': out(['ok'=>true,'rows'=>$pdo->query("SELECT id,nome,preco FROM servicos WHERE ativo=1 ORDER BY nome")->fetchAll()]);
  case 'options_clients': out(['ok'=>true,'rows'=>$pdo->query("SELECT id,nome FROM clientes ORDER BY nome")->fetchAll()]);
  case 'sales_list':
   $q=$pdo->query("SELECT v.id,v.numero,v.data_venda,COALESCE(c.nome,'Consumidor') cliente,v.status,COALESCE(SUM(i.total),0)-v.desconto total FROM vendas v LEFT JOIN clientes c ON c.id=v.cliente_id LEFT JOIN vendas_itens i ON i.venda_id=v.id GROUP BY v.id ORDER BY v.id DESC");out(['ok'=>true,'rows'=>$q->fetchAll()]);
  case 'sale_save':
   $d=$in['data']??[];$items=$d['items']??[];if(!$items)throw new Exception('Adicione itens.');
   $pdo->beginTransaction();
   $num=(int)$pdo->query('SELECT COALESCE(MAX(numero),11059)+1 FROM vendas')->fetchColumn();$des=(float)($d['desconto']??0);
   $st=$pdo->prepare('INSERT INTO vendas(numero,cliente_id,usuario_id,desconto,observacoes,observacoes_tecnicas,status) VALUES(?,?,?,?,?,?,\'FINALIZADA\')');$st->execute([$num,($d['cliente_id']??'')?:null,$_SESSION['usuario_id'],$des,$d['observacoes']??'',$d['observacoes_tecnicas']??'']);$vid=(int)$pdo->lastInsertId();$total=0;
   $pp=$pdo->prepare('SELECT id,nome,preco,estoque FROM produtos WHERE id=? AND ativo=1 FOR UPDATE');$ss=$pdo->prepare('SELECT id,nome,preco FROM servicos WHERE id=? AND ativo=1');$ii=$pdo->prepare('INSERT INTO vendas_itens(venda_id,tipo,produto_id,servico_id,descricao,preco_unitario,quantidade,desconto,total) VALUES(?,?,?,?,?,?,?,?,?)');$mv=$pdo->prepare('INSERT INTO movimentacoes_estoque(produto_id,tipo,quantidade,origem,referencia_id) VALUES(?,\'SAIDA\',?,\'VENDA\',?)');$up=$pdo->prepare('UPDATE produtos SET estoque=estoque-? WHERE id=?');
   foreach($items as $it){$tipo=$it['tipo']==='SERVICO'?'SERVICO':'PRODUTO';$rid=(int)$it['ref_id'];$qtd=(float)$it['quantidade'];$pre=(float)$it['preco'];if($qtd<=0)throw new Exception('Quantidade inválida.');$prodId=$servId=null;
    if($tipo==='PRODUTO'){ $pp->execute([$rid]);$p=$pp->fetch();if(!$p)throw new Exception('Produto não encontrado.');if((float)$p['estoque']<$qtd)throw new Exception("Estoque insuficiente para {$p['nome']}. Disponível: {$p['estoque']}");$desc=$p['nome'];$prodId=$p['id'];$up->execute([$qtd,$p['id']]);$mv->execute([$p['id'],$qtd,$vid]); }
    else{$ss->execute([$rid]);$p=$ss->fetch();if(!$p)throw new Exception('Serviço não encontrado.');$desc=$p['nome'];$servId=$p['id'];}
    $line=$qtd*$pre;$total+=$line;$ii->execute([$vid,$tipo,$prodId,$servId,$desc,$pre,$qtd,0,$line]);
   }
   if($total-$des<0)throw new Exception('Desconto maior que o total.');$fin=$pdo->prepare('INSERT INTO financeiro(venda_id,descricao,tipo,valor,vencimento,pagamento,forma_pagamento,status) VALUES(?,?,\'RECEITA\',?,?,?,?,?)');$fin->execute([$vid,'Venda #'.$num,$total-$des,date('Y-m-d'),null,'Não informado','PENDENTE']);$pdo->commit();out(['ok'=>true,'id'=>$vid,'numero'=>$num]);
  case 'sale_cancel':
   $pdo->beginTransaction();
   $st=$pdo->prepare("SELECT id,status FROM vendas WHERE id=? FOR UPDATE");$st->execute([$id]);$sale=$st->fetch();if(!$sale)throw new Exception('Venda não encontrada.');if($sale['status']==='CANCELADA')throw new Exception('Venda já está cancelada.');
   $items=$pdo->prepare("SELECT produto_id,quantidade FROM vendas_itens WHERE venda_id=? AND tipo='PRODUTO'");$items->execute([$id]);$up=$pdo->prepare('UPDATE produtos SET estoque=estoque+? WHERE id=?');$mv=$pdo->prepare("INSERT INTO movimentacoes_estoque(produto_id,tipo,quantidade,origem,referencia_id) VALUES(?, 'ENTRADA', ?, 'CANCELAMENTO_VENDA', ?)");
   foreach($items as $it){if($it['produto_id']){$up->execute([$it['quantidade'],$it['produto_id']]);$mv->execute([$it['produto_id'],$it['quantidade'],$id]);}}
   $pdo->prepare("UPDATE vendas SET status='CANCELADA' WHERE id=?")->execute([$id]);$pdo->prepare("UPDATE financeiro SET status='CANCELADO' WHERE venda_id=? AND status<>'CANCELADO'")->execute([$id]);$pdo->commit();out(['ok'=>true]);
  case 'finance_list': out(['ok'=>true,'rows'=>$pdo->query('SELECT * FROM financeiro ORDER BY id DESC')->fetchAll()]);
  case 'finance_save': $d=$data;if(empty($d['descricao'])||!isset($d['valor']))throw new Exception('Descrição e valor são obrigatórios.');$st=$pdo->prepare('INSERT INTO financeiro(descricao,tipo,valor,vencimento,forma_pagamento,status) VALUES(?,?,?,?,?,\'PENDENTE\')');$st->execute([$d['descricao'],$d['tipo']??'RECEITA',(float)$d['valor'],$d['vencimento']?:null,$d['forma_pagamento']??null]);out(['ok'=>true]);
  case 'finance_pay': $st=$pdo->prepare("UPDATE financeiro SET status='PAGO',pagamento=CURDATE() WHERE id=?");$st->execute([$id]);out(['ok'=>true]);
  default: throw new Exception('Ação não encontrada.');
 }
}catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();http_response_code(400);out(['ok'=>false,'message'=>$e->getMessage()]);}

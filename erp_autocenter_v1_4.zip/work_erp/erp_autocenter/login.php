<?php
declare(strict_types=1);
session_start();
require_once __DIR__.'/php/db_connect.php';
if (!empty($_SESSION['usuario_id'])) { header('Location: index.php'); exit; }
$erro = ''; $logout = isset($_GET['logout']);
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $login = trim($_POST['login'] ?? '');
    $senha = $_POST['senha'] ?? '';
    $st = $pdo->prepare('SELECT * FROM usuarios WHERE login=? AND ativo=1 LIMIT 1');
    $st->execute([$login]);
    $u = $st->fetch();
    if ($u && password_verify($senha, $u['senha'])) {
        session_regenerate_id(true);
        $_SESSION['usuario_id'] = (int)$u['id'];
        $_SESSION['usuario_nome'] = $u['nome'];
        $_SESSION['usuario_perfil'] = $u['perfil'];
        header('Location: index.php'); exit;
    }
    $erro = 'Login ou senha inválidos, ou usuário inativo.';
}
?><!doctype html><html lang="pt-BR" data-bs-theme="light"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Login | ERP Autocenter</title><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"><link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet"><link rel="stylesheet" href="css/style.css"></head><body class="login-page"><button type="button" class="btn btn-light position-fixed top-0 end-0 m-3 shadow-sm" id="publicThemeBtn" title="Alternar tema"><i class="bi bi-moon-stars-fill"></i> <span>Tema</span></button><div class="container py-5"><div class="row justify-content-center"><div class="col-sm-10 col-md-6 col-lg-4"><div class="card login-card shadow-lg"><div class="card-body p-4 p-lg-5"><div class="text-center mb-4"><div class="login-logo"><i class="bi bi-car-front-fill"></i></div><h1 class="h3 fw-bold mb-1">ERP AUTOCENTER</h1><p class="text-secondary mb-0">Sistema de gestão integrada</p></div><?php if($logout):?><div class="alert alert-success py-2"><i class="bi bi-check-circle me-1"></i>Sessão encerrada com sucesso.</div><?php endif;?><?php if($erro):?><div class="alert alert-danger py-2"><i class="bi bi-exclamation-circle me-1"></i><?=htmlspecialchars($erro)?></div><?php endif;?><form method="post" autocomplete="on"><div class="mb-3"><label class="form-label">Login</label><div class="input-group"><span class="input-group-text"><i class="bi bi-person"></i></span><input name="login" class="form-control" required autofocus></div></div><div class="mb-3"><label class="form-label">Senha</label><div class="input-group"><span class="input-group-text"><i class="bi bi-lock"></i></span><input type="password" name="senha" class="form-control" required></div></div><button class="btn btn-primary w-100 py-2"><i class="bi bi-box-arrow-in-right me-1"></i> Entrar</button></form><div class="d-flex justify-content-between mt-4 small"><a href="cadastro.php">Criar conta</a><a href="recuperar.php">Esqueci minha senha</a></div><div class="text-center mt-4 pt-3 border-top small text-secondary">Acesso inicial: <b>admin</b> / <b>admin123</b></div></div></div></div></div></div><script>(function(){const t=localStorage.getItem("erp_theme")||"light";document.documentElement.setAttribute("data-bs-theme",t);const b=document.getElementById("publicThemeBtn");if(b){const set=()=>{const d=document.documentElement.getAttribute("data-bs-theme")==="dark";b.innerHTML=d?"<i class="bi bi-sun-fill"></i> <span>Tema</span>":"<i class="bi bi-moon-stars-fill"></i> <span>Tema</span>";b.classList.toggle("btn-light",!d);b.classList.toggle("btn-dark",d)};set();b.addEventListener("click",()=>{document.documentElement.setAttribute("data-bs-theme",document.documentElement.getAttribute("data-bs-theme")==="dark"?"light":"dark");localStorage.setItem("erp_theme",document.documentElement.getAttribute("data-bs-theme"));set()})}})();</script></body></html>

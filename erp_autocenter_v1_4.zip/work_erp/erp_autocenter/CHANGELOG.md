# CHANGELOG — ERP Autocenter

## Versão 1.2 — Controle de acesso e recibo configurável

- Acesso obrigatório por `login.php`.
- Redirecionamento de sessão e logout revisados.
- Criado `cadastro.php` com criação de conta.
- Criado `recuperar.php` com token de redefinição.
- Usuários receberam e-mail para recuperação.
- Perfis ampliados: ADMIN, GERENTE, VENDEDOR, TECNICO e ATENDENTE.
- Funcionários passaram a usar seletor de cargo.
- Criadas tabelas `perfil_permissoes` e `usuario_permissoes`.
- Criada matriz de permissões Visualizar/Criar/Editar/Excluir.
- Gestão de usuários com aplicação de perfil e permissões individuais.
- Menus passam a respeitar permissões.
- API passa a validar permissões no servidor, não somente na interface.
- Criada tabela `configuracoes` para partes fixas do recibo.
- Recibo passou a carregar dados fixos do banco.
- Configuração de empresa/recibo adicionada ao sistema.
- Recibo também exige sessão válida.
- Bootstrap 5 e Bootstrap Icons mantidos como padrão visual.

## v1.3 — Tema, pagamento e financeiro
- Logout reforçado com destruição de sessão e cabeçalhos anti-cache.
- Venda agora exige forma de pagamento e vencimento.
- Venda gera financeiro como PAGO para pagamentos imediatos e PENDENTE para A prazo.
- Financeiro ganhou editar e excluir.
- Tema claro/escuro persistente via localStorage e Bootstrap 5.3 data-bs-theme.
- Elementos customizados passaram a usar variáveis de tema.

## v1.4 — Correções solicitadas
- Logout agora destrói a sessão, remove o cookie e impede cache da página protegida.
- Login informa quando a sessão foi encerrada.
- Venda passou a ter seletor obrigatório de forma de pagamento e vencimento.
- Pagamentos imediatos entram como PAGO; A prazo entra como PENDENTE.
- Financeiro passou a permitir editar, baixar e excluir conforme permissão.
- Tema claro/escuro disponível no sistema e também nas telas públicas de login/cadastro/recuperação.
- Bootstrap 5.3 `data-bs-theme` integrado aos componentes e CSS customizado.

# CHANGELOG — ERP Autocenter

## v1.5 — Chaves de registro e numeração fiscal
- Todas as tabelas passam a seguir explicitamente a regra de "número de registro incremental" gerado pelo banco, exceto o Cadastro de Pessoas.
- `clientes` e `funcionarios` (Cadastro de Pessoas) passaram a usar **chave primária composta (CPF + Nome)**, sem coluna `id`.
- Campo `documento` de `clientes` foi substituído por `cpf`, alinhado ao novo padrão.
- `vendas` passou a referenciar o cliente pela chave composta (`cliente_cpf`, `cliente_nome`) em vez de `cliente_id`.
- `produtos.codigo` tornou-se a própria chave primária, gerada automaticamente pelo banco (`AUTO_INCREMENT`); o campo foi **removido do formulário de cadastro/edição** de produto (continua visível, somente leitura, na listagem).
- Numeração de `vendas.numero` (nota/recibo) agora **começa em 0**.
- `api.php` reescrito para tratar de forma genérica módulos com chave composta (clientes/funcionarios), módulos com chave `codigo` (produtos) e módulos com `id` (servicos).
- `js/app.js`: CRUD genérico, tela de vendas e recibo atualizados para os novos formatos de chave.
- `gerar_recibo.php` atualizado para o novo relacionamento cliente↔venda e para exibir CPF em vez de "Documento".

## Versão 1.2 — Controle de acesso e recibo configurável

- Acesso obrigatório por `login.php`.
- Redirecionamento de sessão e logout revisados.
- Criado `cadastro.php` com criação de conta.
- Criado `recuperar.php` com token de redefinição.
- Usuários receberam e-mail para recuperação.
- Perfis ampliados: ADMIN, GERENTE, VENDEDOR, TECNICO e ATENDENTE.
- Funcionários passaram a usar seletor de cargo.
- Criadas tabelas `perfil_permissoes` e `usuario_permissoes`.
- Criada matriz de permissões Visualizar/Criar/Editar/Excluir.
- Gestão de usuários com aplicação de perfil e permissões individuais.
- Menus passam a respeitar permissões.
- API passa a validar permissões no servidor, não somente na interface.
- Criada tabela `configuracoes` para partes fixas do recibo.
- Recibo passou a carregar dados fixos do banco.
- Configuração de empresa/recibo adicionada ao sistema.
- Recibo também exige sessão válida.
- Bootstrap 5 e Bootstrap Icons mantidos como padrão visual.

## v1.3 — Tema, pagamento e financeiro
- Logout reforçado com destruição de sessão e cabeçalhos anti-cache.
- Venda agora exige forma de pagamento e vencimento.
- Venda gera financeiro como PAGO para pagamentos imediatos e PENDENTE para A prazo.
- Financeiro ganhou editar e excluir.
- Tema claro/escuro persistente via localStorage e Bootstrap 5.3 data-bs-theme.
- Elementos customizados passaram a usar variáveis de tema.

## v1.4 — Correções solicitadas
- Logout agora destrói a sessão, remove o cookie e impede cache da página protegida.
- Login informa quando a sessão foi encerrada.
- Venda passou a ter seletor obrigatório de forma de pagamento e vencimento.
- Pagamentos imediatos entram como PAGO; A prazo entra como PENDENTE.
- Financeiro passou a permitir editar, baixar e excluir conforme permissão.
- Tema claro/escuro disponível no sistema e também nas telas públicas de login/cadastro/recuperação.
- Bootstrap 5.3 `data-bs-theme` integrado aos componentes e CSS customizado.

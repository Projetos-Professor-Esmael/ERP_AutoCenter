<?php
declare(strict_types=1);
require_once __DIR__.'/../php/auth.php';
require_once __DIR__.'/../php/db_connect.php';
header('Content-Type: application/json; charset=utf-8');
if(empty($_SESSION['usuario_id'])){http_response_code(401);echo json_encode(['ok'=>false,'message'=>'Sessão expirada.']);exit;}
function input():array{$raw=file_get_contents('php://input');return $raw?(json_decode($raw,true)?:[]):$_POST;}
function out(array $x):never{echo json_encode($x,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);exit;}
function clean(array $d):array{foreach($d as $k=>$v)if(is_string($v))$d[$k]=trim($v);return $d;}
$action=$_GET['action']??'';$in=input();$module=$in['module']??'';$id=(int)($in['id']??0);$data=clean($in['data']??[]);
$modules=['dashboard','clientes','produtos','servicos','vendas','financeiro','funcionarios','usuarios','configuracoes'];

// Campos editáveis por módulo. "clientes" e "funcionarios" são CADASTRO DE
// PESSOAS: usam chave primária composta (cpf, nome) em vez de "id".
// Em "produtos" o campo "codigo" não é editável: é gerado pelo banco (AUTO_INCREMENT).
$allowed=[
 'clientes'=>['cpf','nome','telefone','email','endereco','cidade','estado','ativo'],
 'produtos'=>['nome','categoria','estoque','estoque_minimo','preco','ativo'],
 'servicos'=>['nome','descricao','preco','ativo'],
 'funcionarios'=>['cpf','nome','cargo','telefone','ativo'],
];
$compositeModules=['clientes','funcionarios']; // chave primária composta (cpf, nome)
$pkColumn=['produtos'=>'codigo','servicos'=>'id']; // coluna de número de registro / código dos demais módulos
$orderBy=['produtos'=>'codigo DESC','servicos'=>'id DESC','clientes'=>'criado_em DESC','funcionarios'=>'criado_em DESC'];

try{
 switch($action){
 case 'me': $pm=[]; foreach($modules as $m){$st=$pdo->prepare('SELECT visualizar,criar,editar,excluir FROM usuario_permissoes WHERE usuario_id=? AND modulo=? LIMIT 1');$st->execute([(int)$_SESSION['usuario_id'],$m]);$pm[$m]=$st->fetch()?:['visualizar'=>0,'criar'=>0,'editar'=>0,'excluir'=>0];} if(($_SESSION['usuario_perfil']??'')==='ADMIN') foreach($modules as $m)$pm[$m]=['visualizar'=>1,'criar'=>1,'editar'=>1,'excluir'=>1]; out(['ok'=>true,'usuario'=>usuario_atual(),'permissions'=>$pm]);

 case 'dashboard': exigir_permissao($pdo,'dashboard'); $fat=(float)$pdo->query("SELECT COALESCE(SUM(valor),0) FROM financeiro WHERE tipo='RECEITA' AND status='PAGO'")->fetchColumn();$pend=(float)$pdo->query("SELECT COALESCE(SUM(valor),0) FROM financeiro WHERE status='PENDENTE'")->fetchColumn();out(['ok'=>true,'faturamento'=>$fat,'pendente'=>$pend,'vendas'=>(int)$pdo->query("SELECT COUNT(*) FROM vendas WHERE status<>'CANCELADA'")->fetchColumn(),'produtos'=>(int)$pdo->query('SELECT COUNT(*) FROM produtos WHERE ativo=1')->fetchColumn()]);

 case 'list':
   exigir_permissao($pdo,$module,'visualizar');
   if(!isset($allowed[$module])&&$module!=='usuarios')throw new Exception('Módulo inválido.');
   $order=$orderBy[$module]??'id DESC';
   $rows=$pdo->query("SELECT * FROM `$module` ORDER BY $order")->fetchAll();
   out(['ok'=>true,'rows'=>$rows]);

 case 'save':
   if(!isset($allowed[$module]))throw new Exception('Módulo inválido.');
   $isComposite=in_array($module,$compositeModules,true);
   if($isComposite){
     $pkIn=$in['pk']??[];
     $origCpf=trim((string)($pkIn['cpf']??''));
     $origNome=trim((string)($pkIn['nome']??''));
     $isNew=($origCpf===''||$origNome==='');
   } else {
     $isNew=!$id;
   }
   exigir_permissao($pdo,$module,$isNew?'criar':'editar');
   $cols=$allowed[$module];$d=[];foreach($cols as $c)if(array_key_exists($c,$data))$d[$c]=$data[$c];
   if($module==='clientes'||$module==='funcionarios')$d['ativo']=(int)($d['ativo']??1);
   if($module==='produtos'){foreach(['estoque','estoque_minimo','preco']as$n)$d[$n]=(float)($d[$n]??0);$d['ativo']=(int)($d['ativo']??1);}
   if($module==='servicos'){$d['preco']=(float)($d['preco']??0);$d['ativo']=(int)($d['ativo']??1);}
   if($module==='funcionarios'&&!in_array($d['cargo']??'', ['GERENTE','VENDEDOR','TECNICO','ADMINISTRADOR'],true))throw new Exception('Cargo inválido.');

   if($isComposite){
     $cpf=trim((string)($d['cpf']??''));$nome=trim((string)($d['nome']??''));
     if($cpf===''||$nome==='')throw new Exception('CPF e nome são obrigatórios.');
     if($isNew){
       $chk=$pdo->prepare("SELECT 1 FROM `$module` WHERE cpf=? AND nome=? LIMIT 1");$chk->execute([$cpf,$nome]);
       if($chk->fetch())throw new Exception('Já existe um registro com este CPF e nome.');
       $keys=array_keys($d);
       $st=$pdo->prepare("INSERT INTO `$module` (`".implode('`,`',$keys)."`) VALUES (".implode(',',array_fill(0,count($keys),'?')).")");
       $st->execute(array_values($d));
     } else {
       if($cpf!==$origCpf||$nome!==$origNome){
         $chk=$pdo->prepare("SELECT 1 FROM `$module` WHERE cpf=? AND nome=? LIMIT 1");$chk->execute([$cpf,$nome]);
         if($chk->fetch())throw new Exception('Já existe um registro com este CPF e nome.');
       }
       $set=implode(',',array_map(fn($c)=>"`$c`=?",array_keys($d)));
       if(!$set)throw new Exception('Nenhum dado para atualizar.');
       $vals=array_values($d);$vals[]=$origCpf;$vals[]=$origNome;
       $st=$pdo->prepare("UPDATE `$module` SET $set WHERE cpf=? AND nome=?");$st->execute($vals);
     }
     out(['ok'=>true,'pk'=>['cpf'=>$cpf,'nome'=>$nome]]);
   } else {
     $col=$pkColumn[$module]??'id';
     if($id){
       $set=implode(',',array_map(fn($c)=>"`$c`=?",array_keys($d)));if(!$set)throw new Exception('Nenhum dado para atualizar.');
       $vals=array_values($d);$vals[]=$id;
       $st=$pdo->prepare("UPDATE `$module` SET $set WHERE `$col`=?");$st->execute($vals);
     } else {
       $keys=array_keys($d);
       $st=$pdo->prepare("INSERT INTO `$module` (`".implode('`,`',$keys)."`) VALUES (".implode(',',array_fill(0,count($keys),'?')).")");
       $st->execute(array_values($d));$id=(int)$pdo->lastInsertId();
     }
     out(['ok'=>true,'id'=>$id]);
   }

 case 'delete':
   exigir_permissao($pdo,$module,'excluir');
   if(!isset($allowed[$module]))throw new Exception('Módulo inválido.');
   if(in_array($module,$compositeModules,true)){
     $pkIn=$in['pk']??[];$cpf=trim((string)($pkIn['cpf']??''));$nome=trim((string)($pkIn['nome']??''));
     if($cpf===''||$nome==='')throw new Exception('Registro inválido.');
     $pdo->prepare("DELETE FROM `$module` WHERE cpf=? AND nome=?")->execute([$cpf,$nome]);
   } else {
     $col=$pkColumn[$module]??'id';
     $pdo->prepare("DELETE FROM `$module` WHERE `$col`=?")->execute([$id]);
   }
   out(['ok'=>true]);

 case 'options_products': exigir_permissao($pdo,'vendas');out(['ok'=>true,'rows'=>$pdo->query("SELECT codigo AS id,nome,preco,estoque FROM produtos WHERE ativo=1 ORDER BY nome")->fetchAll()]);
 case 'options_services': exigir_permissao($pdo,'vendas');out(['ok'=>true,'rows'=>$pdo->query("SELECT id,nome,preco FROM servicos WHERE ativo=1 ORDER BY nome")->fetchAll()]);
 case 'options_clients': exigir_permissao($pdo,'vendas');out(['ok'=>true,'rows'=>$pdo->query("SELECT cpf,nome FROM clientes WHERE ativo=1 ORDER BY nome")->fetchAll()]);

 case 'sales_list': exigir_permissao($pdo,'vendas');$q=$pdo->query("SELECT v.id,v.numero,v.data_venda,COALESCE(c.nome,'Consumidor') cliente,v.status,COALESCE(SUM(i.total),0)-v.desconto total FROM vendas v LEFT JOIN clientes c ON c.cpf=v.cliente_cpf AND c.nome=v.cliente_nome LEFT JOIN vendas_itens i ON i.venda_id=v.id GROUP BY v.id ORDER BY v.id DESC");out(['ok'=>true,'rows'=>$q->fetchAll()]);

 case 'sale_save':
   exigir_permissao($pdo,'vendas','criar');$d=$in['data']??[];$items=$d['items']??[];if(!$items)throw new Exception('Adicione itens.');$pdo->beginTransaction();
   // notas fiscais começam a numeração em 0 (COALESCE ... -1)
   $num=(int)$pdo->query('SELECT COALESCE(MAX(numero),-1)+1 FROM vendas')->fetchColumn();$des=(float)($d['desconto']??0);
   $clienteCpf=trim((string)($d['cliente_cpf']??''))?:null;
   $clienteNome=trim((string)($d['cliente_nome']??''))?:null;
   if($clienteCpf&&!$clienteNome)throw new Exception('Cliente inválido.');
   $st=$pdo->prepare("INSERT INTO vendas(numero,cliente_cpf,cliente_nome,usuario_id,desconto,observacoes,observacoes_tecnicas,status) VALUES(?,?,?,?,?,?,?, 'FINALIZADA')");$st->execute([$num,$clienteCpf,$clienteNome,$_SESSION['usuario_id'],$des,$d['observacoes']??'',$d['observacoes_tecnicas']??'']);$vid=(int)$pdo->lastInsertId();$total=0;
   $pp=$pdo->prepare('SELECT codigo AS id,nome,preco,estoque FROM produtos WHERE codigo=? AND ativo=1 FOR UPDATE');$ss=$pdo->prepare('SELECT id,nome,preco FROM servicos WHERE id=? AND ativo=1');$ii=$pdo->prepare('INSERT INTO vendas_itens(venda_id,tipo,produto_id,servico_id,descricao,preco_unitario,quantidade,desconto,total) VALUES(?,?,?,?,?,?,?,?,?)');$mv=$pdo->prepare("INSERT INTO movimentacoes_estoque(produto_id,tipo,quantidade,origem,referencia_id) VALUES(?, 'SAIDA', ?, 'VENDA', ?)");$up=$pdo->prepare('UPDATE produtos SET estoque=estoque-? WHERE codigo=?');
   foreach($items as $it){$tipo=($it['tipo']??'')==='SERVICO'?'SERVICO':'PRODUTO';$rid=(int)($it['ref_id']??0);$qtd=(float)($it['quantidade']??0);if($qtd<=0)throw new Exception('Quantidade inválida.');$pre=(float)($it['preco']??0);$prodId=$servId=null;if($tipo==='PRODUTO'){$pp->execute([$rid]);$p=$pp->fetch();if(!$p)throw new Exception('Produto não encontrado.');if((float)$p['estoque']<$qtd)throw new Exception("Estoque insuficiente para {$p['nome']}. Disponível: {$p['estoque']}");$desc=$p['nome'];$prodId=(int)$p['id'];$up->execute([$qtd,$prodId]);$mv->execute([$prodId,$qtd,$vid]);}else{$ss->execute([$rid]);$p=$ss->fetch();if(!$p)throw new Exception('Serviço não encontrado.');$desc=$p['nome'];$servId=(int)$p['id'];}$line=$qtd*$pre;$total+=$line;$ii->execute([$vid,$tipo,$prodId,$servId,$desc,$pre,$qtd,0,$line]);}
   if($total-$des<0)throw new Exception('Desconto maior que o total.');$forma=$d['forma_pagamento']??'';if(!in_array($forma,['PIX','Dinheiro','Cartão de Débito','Cartão de Crédito','Boleto','Transferência','A prazo'],true))throw new Exception('Forma de pagamento inválida.');$statusFin=$forma==='A prazo'?'PENDENTE':'PAGO';$venc=$d['vencimento']??date('Y-m-d');$pag=$statusFin==='PAGO'?date('Y-m-d'):null;$fin=$pdo->prepare("INSERT INTO financeiro(venda_id,descricao,tipo,valor,vencimento,pagamento,forma_pagamento,status) VALUES(?,?,'RECEITA',?,?,?,?,?)");$fin->execute([$vid,'Venda #'.$num,$total-$des,$venc,$pag,$forma,$statusFin]);$pdo->commit();out(['ok'=>true,'id'=>$vid,'numero'=>$num]);

 case 'sale_cancel': exigir_permissao($pdo,'vendas','editar');$pdo->beginTransaction();$st=$pdo->prepare('SELECT id,status FROM vendas WHERE id=? FOR UPDATE');$st->execute([$id]);$sale=$st->fetch();if(!$sale)throw new Exception('Venda não encontrada.');if($sale['status']==='CANCELADA')throw new Exception('Venda já cancelada.');$items=$pdo->prepare("SELECT produto_id,quantidade FROM vendas_itens WHERE venda_id=? AND tipo='PRODUTO'");$items->execute([$id]);$up=$pdo->prepare('UPDATE produtos SET estoque=estoque+? WHERE codigo=?');$mv=$pdo->prepare("INSERT INTO movimentacoes_estoque(produto_id,tipo,quantidade,origem,referencia_id) VALUES(?, 'ENTRADA', ?, 'CANCELAMENTO_VENDA', ?)");foreach($items as $it)if($it['produto_id']){$up->execute([$it['quantidade'],$it['produto_id']]);$mv->execute([$it['produto_id'],$it['quantidade'],$id]);}$pdo->prepare("UPDATE vendas SET status='CANCELADA' WHERE id=?")->execute([$id]);$pdo->prepare("UPDATE financeiro SET status='CANCELADO' WHERE venda_id=? AND status<>'CANCELADO'")->execute([$id]);$pdo->commit();out(['ok'=>true]);

 case 'sale_detail': exigir_permissao($pdo,'vendas');$st=$pdo->prepare("SELECT v.*,c.nome cliente_nome,c.cpf,c.telefone,c.email,c.endereco,c.cidade,c.estado,u.nome vendedor FROM vendas v LEFT JOIN clientes c ON c.cpf=v.cliente_cpf AND c.nome=v.cliente_nome LEFT JOIN usuarios u ON u.id=v.usuario_id WHERE v.id=?");$st->execute([$id]);$v=$st->fetch();if(!$v)throw new Exception('Venda não encontrada.');$st=$pdo->prepare('SELECT * FROM vendas_itens WHERE venda_id=? ORDER BY id');$st->execute([$id]);$it=$st->fetchAll();$st=$pdo->prepare('SELECT * FROM financeiro WHERE venda_id=? ORDER BY id');$st->execute([$id]);out(['ok'=>true,'venda'=>$v,'itens'=>$it,'financeiro'=>$st->fetchAll()]);

 case 'finance_list': exigir_permissao($pdo,'financeiro');out(['ok'=>true,'rows'=>$pdo->query('SELECT * FROM financeiro ORDER BY id DESC')->fetchAll()]);
 case 'finance_save': $fid=(int)($in['id']??0); exigir_permissao($pdo,'financeiro',$fid?'editar':'criar'); if(empty($data['descricao'])||!isset($data['valor']))throw new Exception('Descrição e valor são obrigatórios.'); $status=$data['status']??'PENDENTE'; if(!in_array($status,['PENDENTE','PAGO','CANCELADO'],true))$status='PENDENTE'; $pagamento=$status==='PAGO'?($data['pagamento']??date('Y-m-d')):null; if($fid){$st=$pdo->prepare("UPDATE financeiro SET descricao=?,tipo=?,valor=?,vencimento=?,pagamento=?,forma_pagamento=?,status=? WHERE id=?");$st->execute([$data['descricao'],$data['tipo']??'RECEITA',(float)$data['valor'],$data['vencimento']?:null,$pagamento,$data['forma_pagamento']??'Não informado',$status,$fid]);}else{$st=$pdo->prepare("INSERT INTO financeiro(descricao,tipo,valor,vencimento,pagamento,forma_pagamento,status) VALUES(?,?,?,?,?,?,?)");$st->execute([$data['descricao'],$data['tipo']??'RECEITA',(float)$data['valor'],$data['vencimento']?:null,$pagamento,$data['forma_pagamento']??'Não informado',$status]);}out(['ok'=>true,'id'=>$fid?:(int)$pdo->lastInsertId()]);
 case 'finance_pay': exigir_permissao($pdo,'financeiro','editar');$pdo->prepare("UPDATE financeiro SET status='PAGO',pagamento=CURDATE() WHERE id=?")->execute([$id]);out(['ok'=>true]);
 case 'finance_delete': exigir_permissao($pdo,'financeiro','excluir');$st=$pdo->prepare('SELECT venda_id FROM financeiro WHERE id=?');$st->execute([$id]);$f=$st->fetch();if(!$f)throw new Exception('Lançamento não encontrado.');$pdo->prepare('DELETE FROM financeiro WHERE id=?')->execute([$id]);out(['ok'=>true]);

 case 'settings_get': exigir_permissao($pdo,'configuracoes');$rows=$pdo->query('SELECT chave,valor FROM configuracoes')->fetchAll();$r=[];foreach($rows as $x)$r[$x['chave']]=$x['valor'];out(['ok'=>true,'settings'=>$r]);
 case 'settings_save': exigir_permissao($pdo,'configuracoes','editar');$allowedKeys=['empresa_nome','empresa_telefone','empresa_atividade','empresa_pix','empresa_responsavel','recibo_titulo','recibo_rodape','recibo_observacao_padrao'];$st=$pdo->prepare('INSERT INTO configuracoes(chave,valor) VALUES(?,?) ON DUPLICATE KEY UPDATE valor=VALUES(valor)');foreach($data as $k=>$v)if(in_array($k,$allowedKeys,true))$st->execute([$k,$v]);out(['ok'=>true]);

 case 'user_detail': exigir_admin();$st=$pdo->prepare('SELECT id,nome,email,login,perfil,ativo FROM usuarios WHERE id=?');$st->execute([$id]);$u=$st->fetch();if(!$u)throw new Exception('Usuário não encontrado.');$st=$pdo->prepare('SELECT modulo,visualizar,criar,editar,excluir FROM usuario_permissoes WHERE usuario_id=?');$st->execute([$id]);out(['ok'=>true,'usuario'=>$u,'permissions'=>$st->fetchAll()]);
 case 'users_list': exigir_admin();out(['ok'=>true,'rows'=>$pdo->query('SELECT id,nome,email,login,perfil,ativo,criado_em FROM usuarios ORDER BY id DESC')->fetchAll()]);
 case 'user_save': exigir_admin();$u=$in['data']??[];$uid=(int)($in['id']??0);if(!$u['nome']||!$u['login'])throw new Exception('Nome e login são obrigatórios.');$pdo->beginTransaction();if($uid){$fields=['nome','email','login','perfil','ativo'];$vals=[];foreach($fields as $f)$vals[]=$u[$f]??null;$sql='UPDATE usuarios SET nome=?,email=?,login=?,perfil=?,ativo=?';if(!empty($u['senha'])){$sql.=',senha=?';$vals[]=password_hash($u['senha'],PASSWORD_DEFAULT);}$sql.=' WHERE id=?';$vals[]=$uid;$pdo->prepare($sql)->execute($vals);}else{if(empty($u['senha']))throw new Exception('Informe a senha.');$st=$pdo->prepare('INSERT INTO usuarios(nome,email,login,senha,perfil,ativo) VALUES(?,?,?,?,?,?)');$st->execute([$u['nome'],$u['email']??null,$u['login'],password_hash($u['senha'],PASSWORD_DEFAULT),$u['perfil']??'ATENDENTE',(int)($u['ativo']??1)]);$uid=(int)$pdo->lastInsertId();}$pdo->commit();out(['ok'=>true,'id'=>$uid]);
 case 'user_permissions_save': exigir_admin();$uid=(int)($in['id']??0);$perms=$in['permissions']??[];$st=$pdo->prepare('SELECT id FROM usuarios WHERE id=?');$st->execute([$uid]);if(!$st->fetch())throw new Exception('Usuário não encontrado.');$pdo->beginTransaction();$del=$pdo->prepare('DELETE FROM usuario_permissoes WHERE usuario_id=?');$del->execute([$uid]);$ins=$pdo->prepare('INSERT INTO usuario_permissoes(usuario_id,modulo,visualizar,criar,editar,excluir) VALUES(?,?,?,?,?,?)');foreach($perms as $m=>$p)$ins->execute([$uid,$m,(int)($p['visualizar']??0),(int)($p['criar']??0),(int)($p['editar']??0),(int)($p['excluir']??0)]);$pdo->commit();out(['ok'=>true]);
 case 'user_apply_profile': exigir_admin();$uid=(int)($in['id']??0);$perfil=$in['perfil']??'ATENDENTE';$st=$pdo->prepare('SELECT id FROM usuarios WHERE id=?');$st->execute([$uid]);if(!$st->fetch())throw new Exception('Usuário não encontrado.');$pdo->beginTransaction();$pdo->prepare('DELETE FROM usuario_permissoes WHERE usuario_id=?')->execute([$uid]);$st=$pdo->prepare('INSERT INTO usuario_permissoes(usuario_id,modulo,visualizar,criar,editar,excluir) SELECT ?,modulo,visualizar,criar,editar,excluir FROM perfil_permissoes WHERE perfil=?');$st->execute([$uid,$perfil]);$pdo->commit();out(['ok'=>true]);

 default: throw new Exception('Ação não encontrada.');
 }
}catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();http_response_code(400);out(['ok'=>false,'message'=>$e->getMessage()]);}
